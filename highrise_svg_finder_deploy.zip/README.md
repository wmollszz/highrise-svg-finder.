# Highrise SVG Finder

A small Flask app that searches public Highrise users by username through the official Web API and checks the returned profile for `avatar_svg` / `avatar_url`.

## Deploy free on Render
1. Create a GitHub repository and upload the contents of this folder.
2. In Render, choose **New + → Web Service** and connect the repository.
3. Render detects `render.yaml`, or set:
   - Build command: `pip install -r requirements.txt`
   - Start command: `gunicorn app:app`
4. Deploy and open the generated `https://...onrender.com` URL.

## Important
This app does not fabricate an SVG if the official API only returns a raster avatar. API availability, profile fields and hosting policies can change. Do not add account passwords or private tokens.
