import os
from flask import Flask, jsonify, request, send_from_directory
import requests

app = Flask(__name__, static_folder="static")
BASE = "https://webapi.highrise.game"
TIMEOUT = 15
SESSION = requests.Session()
SESSION.headers.update({
    "Accept": "application/json",
    "User-Agent": "Highrise-SVG-Finder/1.0 (community utility)"
})

@app.get("/")
def home():
    return send_from_directory("static", "index.html")

def upstream(path, params=None):
    try:
        response = SESSION.get(BASE + path, params=params, timeout=TIMEOUT)
    except requests.RequestException as exc:
        return jsonify({"error": "Не удалось подключиться к API Highrise. Попробуй позже.", "detail": str(exc)}), 502
    content_type = response.headers.get("content-type", "")
    if response.status_code >= 400:
        return jsonify({"error": f"API Highrise вернул HTTP {response.status_code}.", "detail": response.text[:400]}), response.status_code
    if "json" not in content_type.lower():
        return jsonify({"error": "API Highrise вернул неожиданный формат ответа.", "detail": response.text[:400]}), 502
    try:
        return jsonify(response.json())
    except ValueError:
        return jsonify({"error": "Не удалось прочитать JSON от API Highrise."}), 502

@app.get("/api/users")
def users():
    username = request.args.get("username", "").strip().lstrip("@")
    if not username:
        return jsonify({"error": "Укажи игровой ник."}), 400
    return upstream("/users", {"username": username, "limit": 10})

@app.get("/api/users/<user_id>")
def user(user_id):
    if not user_id or len(user_id) > 200:
        return jsonify({"error": "Некорректный ID пользователя."}), 400
    return upstream("/users/" + user_id)

@app.get("/health")
def health():
    return jsonify({"ok": True})

if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5000"))
    app.run(host="0.0.0.0", port=port)
